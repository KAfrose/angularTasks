import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-core',
  templateUrl: './core.component.html',
  styleUrls: ['./core.component.css']
})
export class CoreComponent implements OnInit {
  countries:string[]=["india","australia","japan"];
  show:boolean;
  password:string;
  cpassword:string;
  str:string="this is ustring";
  dt:Date=new Date();
  x:number=152346.766;
  
  constructor() {
    this.show=true;
   }

  ngOnInit(): void {
  }

}
