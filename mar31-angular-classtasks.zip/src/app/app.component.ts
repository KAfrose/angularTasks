import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'mar31-project1';
  fn2(str:any)
  {
    alert('received from child:'+str);
  }
}
