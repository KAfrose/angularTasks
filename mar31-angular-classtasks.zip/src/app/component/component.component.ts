import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-component',
  templateUrl: './component.component.html',
  styleUrls: ['./component.component.css']
})
export class ComponentComponent implements OnInit {
  username:string;
  password:string;
  cpassword:string;
  pwdMessage:string;
  dobMessage:string;
  status:string;
  dateOfBirth:string;
  constructor() {
   // this.dateOfBirth=new Date();
   }

  ngOnInit(): void {
  }
  fnCheckPwds()
  {
    if(this.password!=this.cpassword)
    {
      this.status="failure";
      this.pwdMessage="Passwords does not match";
    }else{
      this.status="success";
      this.pwdMessage="";
    }
  }
  fnCheckDate()
  {
      var dob=new Date(this.dateOfBirth);
      var today=new Date();
      if(dob > today)
      {
        this.status="failure";
        this.dobMessage="date cannot be future";
      }
      else{
        this.status="success"
        this.dobMessage="";
      }
      
  }

}
