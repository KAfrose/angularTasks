import { Component,EventEmitter, Input, OnInit, Output } from '@angular/core';




@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
  

  username:string;
 password:string;
  message:string;
  status:string;
  pwdType:string;
  showPassword:boolean;
  @Output() loginEvent:EventEmitter<string>=new EventEmitter(); 
  
  constructor() { 
    this.pwdType="password";
  
  }
@Input() title:string;
  ngOnInit(): void {
  }
  fn1()
  {
    this.loginEvent.emit(this.username);
    // if(this.username=='rama' && this.password=='ravi')
    //   this.message='<font color="green">login is success</font>';
    // else
    //   this.message='<font color="red">Login is failure</font>';
  }
  fnTogglePassword()
  {
    if(this.showPassword)
      this.pwdType="text";
    else
      this.pwdType="password";
  }
}
